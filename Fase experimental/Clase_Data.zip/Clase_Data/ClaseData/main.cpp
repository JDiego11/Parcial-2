#include "data.h"
int main()
{
    Data info("GameData.txt");
    info.Winner_Historial();
}

