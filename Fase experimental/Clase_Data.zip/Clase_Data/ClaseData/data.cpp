#include "data.h"
Data::Data(string FileName)
{
    try {
        ifstream data(FileName);
        if (!data.is_open()) {
            throw runtime_error("No se pudo abrir el archivo: " + FileName);
        }
        stringstream buffer;
        buffer << data.rdbuf();
        File = buffer.str();
        File += '\n';
        data.close();
    } catch (const std::exception& e) {
        cerr << "Error al abrir el archivo: " << e.what() << endl;
    }
}

void Data::NewData(string Player1, string Player2, int Case, int Num){
    time_t now = time(0);
    string Winner;
    struct tm timeinfo;
    localtime_s(&timeinfo, &now);
    string Players = "Jugadores: " + Player1 + ", " + Player2;
    string Records = "Fichas: " + to_string(Num);
    string Date = "Fecha: " +to_string(timeinfo.tm_mday) +"/"+ to_string(timeinfo.tm_mon +1)+ "/"+ to_string(timeinfo.tm_year+1900);
    string Time = "Hora: " + to_string(timeinfo.tm_hour) +":"+ to_string(timeinfo.tm_min);
    if (Case == 1) Winner= "Ganador: " + Player1;
    else if(Case==2) Winner = "Ganador: "+ Player2;
    else if(Case==3) Winner = "Ganador: Empate";
    File += '\n' + Players + '\n' + Date + '\n' + Time + '\n' + Winner + '\n' + Records+'\n';
    cout << File << endl;
}

void Data::WriteData(){
    try {
        ofstream archivoSalida("GameData.txt");
        if (!archivoSalida.is_open()) {
            throw std::runtime_error("No se pudo abrir el archivo para escritura.");
        }
        archivoSalida << File << endl;
        archivoSalida.close();
    } catch (const exception& e) {
        std::cerr << "Error: " << e.what() << endl;
    }
}


string Data::GetField(string fieldName, string data) {
    size_t pos = data.find(fieldName);
    if (pos != string::npos) {
        pos += fieldName.length();
        size_t endPos = data.find('\n', pos);
        if (endPos != string::npos) {
            return data.substr(pos, endPos - pos);
        }
    }
    return "No encontrado";
}
void Data::Winner_Historial() {
    string Historial =
        "+------------------+---------------------+-----------------+--------------------+\n"
        "|     Fecha        |       Jugadores     |     Ganador     |     Puntuacion     |\n"
        "+------------------+---------------------+-----------------+--------------------+\n";
    size_t pos = 0;
    while ((pos = File.find("Jugadores: ", pos)) != string::npos) {
        string Players = GetField("Jugadores: ", File.substr(pos));
        string Date = GetField("Fecha: ", File.substr(pos));
        string Winner = GetField("Ganador: ", File.substr(pos));
        string Record = GetField("Fichas: ", File.substr(pos));

        Players.resize(18, ' ');
        Date.resize(12, ' ');
        Winner.resize(16, ' ');
        Record.resize(19, ' ');
        Historial += "|   " + Date + "   |  " + Players + " | " + Winner + "| " + Record + "|\n";

        pos = File.find("Jugadores: ", pos)+1;
        Historial += "+------------------+---------------------+-----------------+--------------------+\n";
    }
    cout << Historial;
}

Data::~Data(){

}
